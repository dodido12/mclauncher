Librerías nativas de terceros (arm64-v8a, bionic), generadas por natives/build-natives.sh:

  libEGL_mesa.so, libgallium-25.3.6.so  Mesa 25.3.6 (Zink, EGL surfaceless) — MIT
  libgl4es_114.so                       gl4es — MIT
  liblwjgl*.so                          LWJGL 3.3.3 — BSD-3-Clause (incluye libffi — MIT)
  libopenal.so                          OpenAL Soft 1.23.1 — LGPL-2.1 (enlazada dinámicamente)
  libfreetype.so                        FreeType 2.13.2 — FTL / GPLv2

No contiene ningún archivo de Mojang.
