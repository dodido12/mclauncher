Coloca aquí (opcional) los runtimes OpenJDK para Android aarch64, comprimidos:
  jre-8-aarch64.tar.xz   jre-17-aarch64.tar.xz   jre-21-aarch64.tar.xz   jre-25-aarch64.tar.xz
Deben ser builds de OpenJDK compiladas para Android/bionic (no las de Linux glibc).
OpenJDK es GPLv2 + Classpath Exception: puedes redistribuirlas incluyendo licencia y
ofreciendo el código fuente. Si no las incluyes, JreManager las descarga desde la URL
que configures en runtimes.json.
