# Software de terceros

| Componente | Licencia | Fuente |
|---|---|---|
| Mesa 3D (Zink) | MIT | https://gitlab.freedesktop.org/mesa/mesa |
| libdrm (estática, dentro de Mesa) | MIT | https://gitlab.freedesktop.org/mesa/drm |
| gl4es | MIT | https://github.com/ptitSeb/gl4es |
| LWJGL 3 | BSD-3-Clause | https://github.com/LWJGL/lwjgl3 |
| libffi | MIT | https://github.com/libffi/libffi |
| OpenAL Soft | LGPL-2.1-or-later | https://github.com/kcat/openal-soft |
| FreeType | FTL o GPLv2 | https://gitlab.freedesktop.org/freetype/freetype |
| GLFW (solo headers) | zlib | https://github.com/glfw/glfw |
| OpenJDK (descargado en el dispositivo desde Termux) | GPLv2 + Classpath Exception | https://github.com/termux/termux-packages |

OpenAL Soft es LGPL: se distribuye como librería dinámica separada y su código fuente está en el enlace.
